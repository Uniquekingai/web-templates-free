/* ═══════════════════════════════════════════════════════════════
   MAGIC NAVIGATION BAR  —  magic-navbar.js
   Usage: <script src="magic-navbar.js"></script> (before </body>)
═══════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  const PARTICLE_COUNT = 6;

  /* ── Build & inject indicator + blob + particles ─────────────────────────── */
  function buildNavbar(wrap) {
    // Indicator dot (above bar)
    const indicator = document.createElement('div');
    indicator.className = 'mnb-indicator';
    wrap.appendChild(indicator);

    // Sliding blob
    const blob = document.createElement('div');
    blob.className = 'mnb-blob';
    wrap.appendChild(blob);

    // Inject particles into every item
    wrap.querySelectorAll('.mnb-item').forEach(item => {
      // Label pill — build from data-label if not present
      if (!item.querySelector('.mnb-label') && item.dataset.label) {
        const lbl = document.createElement('span');
        lbl.className = 'mnb-label';
        lbl.textContent = item.dataset.label;
        item.appendChild(lbl);
      }

      // Particles
      for (let i = 0; i < PARTICLE_COUNT; i++) {
        const p = document.createElement('span');
        p.className = 'mnb-particle';
        item.appendChild(p);
      }
    });

    return { indicator, blob };
  }

  /* ── Position indicator & blob over the active item ─────────────────────── */
  function moveAccents(wrap, item, indicator, blob) {
    const wrapRect = wrap.getBoundingClientRect();
    const itemRect = item.getBoundingClientRect();
    const itemCX   = itemRect.left + itemRect.width  / 2 - wrapRect.left;

    indicator.style.left = (itemCX - parseInt(getComputedStyle(document.documentElement).getPropertyValue('--mnb-indicator-size') || 8) / 2) + 'px';
    blob.style.left       = (itemCX - 32) + 'px';  // 32 = half of 64px blob
  }

  /* ── Activate an item ───────────────────────────────────────────────────── */
  function activate(wrap, item, indicator, blob, burst = false) {
    // Deactivate others
    wrap.querySelectorAll('.mnb-item').forEach(el => {
      el.classList.remove('is-active', 'mnb-burst');
    });

    item.classList.add('is-active');

    // Particle burst on click
    if (burst) {
      // Force reflow to restart animation
      void item.offsetWidth;
      item.classList.add('mnb-burst');
      setTimeout(() => item.classList.remove('mnb-burst'), 700);
    }

    moveAccents(wrap, item, indicator, blob);

    // Ripple
    if (burst) {
      const icon = item.querySelector('.mnb-icon');
      if (icon) {
        const dot = document.createElement('div');
        dot.className = 'mnb-ripple-dot';
        dot.style.cssText = 'width:40px;height:40px;left:calc(50% - 20px);top:calc(50% - 20px);';
        icon.appendChild(dot);
        setTimeout(() => dot.remove(), 580);
      }
    }

    // Fire custom event
    item.dispatchEvent(new CustomEvent('mnb:select', {
      bubbles: true,
      detail: { label: item.dataset.label, item }
    }));
  }

  /* ── Init all navbars ───────────────────────────────────────────────────── */
  function initAll() {
    document.querySelectorAll('.mnb-wrap').forEach(wrap => {
      const { indicator, blob } = buildNavbar(wrap);
      const items = Array.from(wrap.querySelectorAll('.mnb-item'));

      // Click
      items.forEach(item => {
        item.addEventListener('click', () => activate(wrap, item, indicator, blob, true));
      });

      // Position accents on active item (initial)
      const initial = wrap.querySelector('.mnb-item.is-active') || items[0];
      if (initial) {
        // Wait for layout to settle
        requestAnimationFrame(() => {
          initial.classList.add('is-active');
          moveAccents(wrap, initial, indicator, blob);
        });
      }

      // Reposition on resize
      window.addEventListener('resize', () => {
        const active = wrap.querySelector('.mnb-item.is-active');
        if (active) moveAccents(wrap, active, indicator, blob);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

})();
