<?php
/**
 * Plugin Name:       AI Product Manager Agent
 * Plugin URI:        https://your-site.com
 * Description:       مدیریت هوشمند محصولات ووکامرس با هوش مصنوعی | AI-powered WooCommerce product management with cubic dashboard
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            AI Agent
 * Text Domain:       ai-product-agent
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AIPA_VERSION', '1.0.0' );
define( 'AIPA_PLUGIN_FILE', __FILE__ );
define( 'AIPA_PATH', plugin_dir_path( __FILE__ ) );
define( 'AIPA_URL', plugin_dir_url( __FILE__ ) );

/* ============================================================
   MAIN PLUGIN CLASS
   ============================================================ */
final class AI_Product_Agent {

    private static $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu',           [ $this, 'register_menu' ] );
        add_action( 'admin_init',           [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts',[ $this, 'enqueue_assets' ] );
        add_action( 'wp_ajax_aipa_chat',           [ $this, 'ajax_chat' ] );
        add_action( 'wp_ajax_aipa_get_products',   [ $this, 'ajax_get_products' ] );
        add_action( 'wp_ajax_aipa_update_product', [ $this, 'ajax_update_product' ] );
        add_action( 'wp_ajax_aipa_bulk_update',    [ $this, 'ajax_bulk_update' ] );
    }

    /* ── Admin Menu ─────────────────────────────────────────── */
    public function register_menu(): void {
        add_menu_page(
            'AI Product Agent',
            'AI Agent 🤖',
            'manage_woocommerce',
            'ai-product-agent',
            [ $this, 'render_dashboard' ],
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>'),
            25
        );
        add_submenu_page(
            'ai-product-agent',
            'تنظیمات | Settings',
            'تنظیمات',
            'manage_options',
            'ai-product-agent-settings',
            [ $this, 'render_settings' ]
        );
    }

    /* ── Settings ───────────────────────────────────────────── */
    public function register_settings(): void {
        register_setting( 'aipa_group', 'aipa_api_key', [
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ] );
        register_setting( 'aipa_group', 'aipa_default_lang', [
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'fa',
        ] );
        register_setting( 'aipa_group', 'aipa_products_per_page', [
            'sanitize_callback' => 'absint',
            'default'           => 50,
        ] );
    }

    /* ── Enqueue Assets ─────────────────────────────────────── */
    public function enqueue_assets( string $hook ): void {
        if ( strpos( $hook, 'ai-product-agent' ) === false ) return;
        // Google Fonts for Vazirmatn (Persian) + Syne (English display)
        wp_enqueue_style(
            'aipa-fonts',
            'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700&family=Syne:wght@400;600;700;800&display=swap',
            [],
            AIPA_VERSION
        );
    }

    /* ── AJAX: Get Products ─────────────────────────────────── */
    public function ajax_get_products(): void {
        check_ajax_referer( 'aipa_nonce', 'nonce' );

        if ( ! class_exists( 'WooCommerce' ) ) {
            wp_send_json_error( [ 'msg' => 'WooCommerce is not active.' ] );
        }

        $per_page = (int) get_option( 'aipa_products_per_page', 50 );
        $paged    = max( 1, (int) ( $_POST['page'] ?? 1 ) );
        $search   = sanitize_text_field( $_POST['search'] ?? '' );

        $args = [
            'post_type'      => 'product',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'post_status'    => 'publish',
            's'              => $search,
        ];

        $query    = new WP_Query( $args );
        $products = [];

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $p    = wc_get_product( get_the_ID() );
                if ( ! $p ) continue;

                $cats = wp_get_post_terms( get_the_ID(), 'product_cat', [ 'fields' => 'names' ] );
                $tags = wp_get_post_terms( get_the_ID(), 'product_tag', [ 'fields' => 'names' ] );

                $products[] = [
                    'id'            => $p->get_id(),
                    'name'          => $p->get_name(),
                    'price'         => (float) $p->get_price(),
                    'regular_price' => (float) $p->get_regular_price(),
                    'sale_price'    => (float) $p->get_sale_price(),
                    'description'   => wp_strip_all_tags( $p->get_short_description() ),
                    'long_desc'     => wp_strip_all_tags( $p->get_description() ),
                    'categories'    => $cats,
                    'tags'          => $tags,
                    'stock'         => $p->get_stock_quantity(),
                    'sku'           => $p->get_sku(),
                    'status'        => $p->get_status(),
                    'type'          => $p->get_type(),
                    'image'         => get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ) ?: '',
                    'edit_url'      => get_edit_post_link( get_the_ID(), 'raw' ),
                ];
            }
            wp_reset_postdata();
        }

        wp_send_json_success( [
            'products'    => $products,
            'total'       => $query->found_posts,
            'total_pages' => $query->max_num_pages,
            'page'        => $paged,
        ] );
    }

    /* ── AJAX: Update Single Product ────────────────────────── */
    public function ajax_update_product(): void {
        check_ajax_referer( 'aipa_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( [ 'msg' => 'Permission denied.' ] );
        }

        $id      = absint( $_POST['product_id'] ?? 0 );
        $updates = json_decode( stripslashes( $_POST['updates'] ?? '{}' ), true );

        if ( ! $id || ! $updates ) {
            wp_send_json_error( [ 'msg' => 'Invalid data.' ] );
        }

        $p = wc_get_product( $id );
        if ( ! $p ) {
            wp_send_json_error( [ 'msg' => "Product #$id not found." ] );
        }

        $changed = [];

        if ( isset( $updates['regular_price'] ) ) {
            $p->set_regular_price( (string) $updates['regular_price'] );
            $changed[] = 'regular_price';
        }
        if ( isset( $updates['sale_price'] ) ) {
            $p->set_sale_price( (string) $updates['sale_price'] );
            $changed[] = 'sale_price';
        }
        if ( isset( $updates['name'] ) ) {
            $p->set_name( sanitize_text_field( $updates['name'] ) );
            $changed[] = 'name';
        }
        if ( isset( $updates['description'] ) ) {
            $p->set_short_description( wp_kses_post( $updates['description'] ) );
            $changed[] = 'description';
        }
        if ( isset( $updates['sku'] ) ) {
            $p->set_sku( sanitize_text_field( $updates['sku'] ) );
            $changed[] = 'sku';
        }

        $p->save();

        wp_send_json_success( [
            'msg'        => "Product #$id updated.",
            'changed'    => $changed,
            'product_id' => $id,
        ] );
    }

    /* ── AJAX: Bulk Update ──────────────────────────────────── */
    public function ajax_bulk_update(): void {
        check_ajax_referer( 'aipa_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( [ 'msg' => 'Permission denied.' ] );
        }

        $updates = json_decode( stripslashes( $_POST['updates'] ?? '[]' ), true );
        $results = [];

        foreach ( (array) $updates as $upd ) {
            $id = absint( $upd['product_id'] ?? 0 );
            if ( ! $id ) continue;

            $p = wc_get_product( $id );
            if ( ! $p ) {
                $results[] = [ 'id' => $id, 'status' => 'error', 'msg' => 'Not found' ];
                continue;
            }

            if ( isset( $upd['regular_price'] ) ) $p->set_regular_price( (string) $upd['regular_price'] );
            if ( isset( $upd['sale_price'] )    ) $p->set_sale_price(    (string) $upd['sale_price'] );
            if ( isset( $upd['name'] )           ) $p->set_name( sanitize_text_field( $upd['name'] ) );
            if ( isset( $upd['description'] )    ) $p->set_short_description( wp_kses_post( $upd['description'] ) );

            $p->save();
            $results[] = [ 'id' => $id, 'status' => 'ok' ];
        }

        wp_send_json_success( [ 'results' => $results ] );
    }

    /* ── AJAX: Chat with AI ─────────────────────────────────── */
    public function ajax_chat(): void {
        check_ajax_referer( 'aipa_nonce', 'nonce' );

        $api_key = get_option( 'aipa_api_key', '' );
        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'msg' => 'API key not set. Please configure it in Settings.' ] );
        }

        $message  = sanitize_textarea_field( $_POST['message'] ?? '' );
        $history  = json_decode( stripslashes( $_POST['history']  ?? '[]' ), true );
        $products = json_decode( stripslashes( $_POST['products'] ?? '[]' ), true );

        if ( empty( $message ) ) {
            wp_send_json_error( [ 'msg' => 'Empty message.' ] );
        }

        $system = $this->build_system_prompt( $products );

        $messages = array_map( fn( $m ) => [
            'role'    => $m['role'],
            'content' => $m['content'],
        ], (array) $history );

        $messages[] = [ 'role' => 'user', 'content' => $message ];

        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 90,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 4096,
                'system'     => $system,
                'messages'   => $messages,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'msg' => $response->get_error_message() ] );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset( $body['error'] ) ) {
            wp_send_json_error( [ 'msg' => $body['error']['message'] ?? 'API error.' ] );
        }

        $text    = $body['content'][0]['text'] ?? '';
        $actions = $this->extract_actions( $text );
        $clean   = $this->strip_action_blocks( $text );

        wp_send_json_success( [
            'reply'   => $clean,
            'actions' => $actions,
            'raw'     => $text,
        ] );
    }

    /* ── Helpers ────────────────────────────────────────────── */
    private function build_system_prompt( array $products ): string {
        $products_json = wp_json_encode( $products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
        $currency      = get_woocommerce_currency_symbol();
        $site_name     = get_bloginfo( 'name' );

        return <<<PROMPT
You are an expert WooCommerce store assistant for "{$site_name}". You understand BOTH Persian (Farsi) and English perfectly. Always respond in the SAME language the user writes in.

STORE PRODUCTS (current data):
{$products_json}

CURRENCY: {$currency}

YOUR CAPABILITIES:
1. Categorize & analyze products intelligently
2. Update product prices, descriptions, names
3. Report on stock, pricing trends, categories
4. Suggest improvements and optimizations
5. Execute bulk operations when asked

WHEN PERFORMING ACTIONS, include JSON action blocks in your response:

To update a product price:
```action
{"type":"update_price","product_id":ID,"regular_price":PRICE}
```

To update sale price:
```action
{"type":"update_sale_price","product_id":ID,"sale_price":PRICE}
```

To update product name:
```action
{"type":"update_name","product_id":ID,"name":"NEW NAME"}
```

To update product description:
```action
{"type":"update_description","product_id":ID,"description":"NEW DESCRIPTION"}
```

To perform bulk price update (percentage):
```action
{"type":"bulk_price_percent","category":"CATEGORY_NAME","percent":10,"direction":"increase"}
```

To provide categorization suggestion (no DB change):
```action
{"type":"categorize","groups":[{"label":"Electronics","product_ids":[1,2,3]},{"label":"Clothing","product_ids":[4,5]}]}
```

IMPORTANT RULES:
- Be conversational, helpful, and precise
- When you execute an action, explain what you did
- Always confirm changes before describing them as "done" — the UI will handle actual execution
- For Persian responses: use Farsi numerals and natural Farsi business language
- Keep response concise unless asked for detail
PROMPT;
    }

    private function extract_actions( string $text ): array {
        $actions = [];
        if ( preg_match_all( '/```action\s*([\s\S]*?)\s*```/m', $text, $matches ) ) {
            foreach ( $matches[1] as $raw ) {
                $decoded = json_decode( trim( $raw ), true );
                if ( $decoded ) $actions[] = $decoded;
            }
        }
        return $actions;
    }

    private function strip_action_blocks( string $text ): string {
        return trim( preg_replace( '/```action\s*[\s\S]*?```/m', '', $text ) );
    }

    /* ── Render Settings Page ───────────────────────────────── */
    public function render_settings(): void {
        ?>
        <div class="wrap" style="font-family:'Vazirmatn',sans-serif; direction:rtl;">
        <h1 style="display:flex;align-items:center;gap:10px;">
            <span style="font-size:28px;">⚙️</span> تنظیمات AI Product Agent
        </h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'aipa_group' ); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="aipa_api_key">کلید API کلود | Claude API Key</label></th>
                    <td>
                        <input type="password" id="aipa_api_key" name="aipa_api_key"
                               value="<?php echo esc_attr( get_option( 'aipa_api_key' ) ); ?>"
                               class="regular-text" dir="ltr" placeholder="sk-ant-api03-..." />
                        <p class="description">
                            کلید API خود را از <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a> دریافت کنید
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="aipa_default_lang">زبان پیش‌فرض</label></th>
                    <td>
                        <select id="aipa_default_lang" name="aipa_default_lang">
                            <option value="fa" <?php selected( get_option( 'aipa_default_lang', 'fa' ), 'fa' ); ?>>فارسی 🇮🇷</option>
                            <option value="en" <?php selected( get_option( 'aipa_default_lang', 'fa' ), 'en' ); ?>>English 🇬🇧</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="aipa_products_per_page">محصولات در هر صفحه</label></th>
                    <td>
                        <input type="number" id="aipa_products_per_page" name="aipa_products_per_page"
                               value="<?php echo esc_attr( get_option( 'aipa_products_per_page', 50 ) ); ?>"
                               min="10" max="200" class="small-text" />
                    </td>
                </tr>
            </table>
            <?php submit_button( 'ذخیره تنظیمات | Save Settings' ); ?>
        </form>
        </div>
        <?php
    }

    /* ── Render Main Dashboard ──────────────────────────────── */
    public function render_dashboard(): void {
        $nonce    = wp_create_nonce( 'aipa_nonce' );
        $ajax_url = admin_url( 'admin-ajax.php' );
        $def_lang = get_option( 'aipa_default_lang', 'fa' );
        $has_key  = ! empty( get_option( 'aipa_api_key', '' ) );
        $settings_url = admin_url( 'admin.php?page=ai-product-agent-settings' );
        ?>
        <div id="aipa-root">
        <!-- ════════════════════════════════════════════════
             INLINE STYLES — Cubic Dark Dashboard
             ════════════════════════════════════════════════ -->
        <style>
        /* ── Reset & Vars ──────────────────────────── */
        #aipa-root *, #aipa-root *::before, #aipa-root *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        #aipa-root {
            --bg0:    #060b14;
            --bg1:    #0c1524;
            --bg2:    #111e33;
            --bg3:    #162540;
            --border: #1e3a5f;
            --accent: #00c8ff;
            --accent2: #7b61ff;
            --accent3: #00ffb3;
            --warn:   #ff6b35;
            --text:   #c8daf0;
            --text2:  #7a9abf;
            --text3:  #3d6080;
            --white:  #e8f4ff;
            --red:    #ff4d6d;
            --green:  #00e5a0;
            --shadow: 0 8px 32px rgba(0,0,0,.6);

            font-family: 'Vazirmatn', 'Syne', -apple-system, sans-serif;
            background: var(--bg0);
            color: var(--text);
            min-height: 100vh;
            padding: 0;
            overflow-x: hidden;
        }
        @keyframes cubeSpin {
            0%   { transform: rotateX(0deg)   rotateY(0deg); }
            25%  { transform: rotateX(90deg)  rotateY(45deg); }
            50%  { transform: rotateX(180deg) rotateY(90deg); }
            75%  { transform: rotateX(270deg) rotateY(135deg); }
            100% { transform: rotateX(360deg) rotateY(180deg); }
        }
        @keyframes pulse {
            0%,100% { opacity:1; } 50% { opacity:.4; }
        }
        @keyframes slideIn {
            from { opacity:0; transform:translateY(20px); }
            to   { opacity:1; transform:translateY(0); }
        }
        @keyframes shimmer {
            0%   { background-position: -200% center; }
            100% { background-position:  200% center; }
        }
        @keyframes blink {
            0%,100% { opacity:1; } 50% { opacity:0; }
        }
        @keyframes glowPulse {
            0%,100% { box-shadow: 0 0 20px rgba(0,200,255,.3); }
            50%      { box-shadow: 0 0 40px rgba(0,200,255,.7), 0 0 80px rgba(0,200,255,.2); }
        }

        /* ── Header ────────────────────────────────── */
        .aipa-header {
            background: linear-gradient(135deg, var(--bg1) 0%, var(--bg2) 50%, #0a1828 100%);
            border-bottom: 1px solid var(--border);
            padding: 16px 28px;
            display: flex;
            align-items: center;
            gap: 20px;
            position: sticky;
            top: 32px;
            z-index: 100;
            backdrop-filter: blur(20px);
        }
        .aipa-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--accent), var(--accent2), transparent);
        }
        .cube-wrapper {
            width: 44px;
            height: 44px;
            perspective: 120px;
            flex-shrink: 0;
        }
        .cube {
            width: 100%;
            height: 100%;
            position: relative;
            transform-style: preserve-3d;
            animation: cubeSpin 6s linear infinite;
        }
        .cube-face {
            position: absolute;
            width: 44px;
            height: 44px;
            border: 1.5px solid var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        .cube-face.front  { background: rgba(0,200,255,.12); transform: translateZ(22px); }
        .cube-face.back   { background: rgba(123,97,255,.12); transform: rotateY(180deg) translateZ(22px); }
        .cube-face.left   { background: rgba(0,255,179,.08); transform: rotateY(-90deg) translateZ(22px); }
        .cube-face.right  { background: rgba(255,107,53,.08); transform: rotateY(90deg) translateZ(22px); }
        .cube-face.top    { background: rgba(0,200,255,.06); transform: rotateX(90deg) translateZ(22px); }
        .cube-face.bottom { background: rgba(123,97,255,.06); transform: rotateX(-90deg) translateZ(22px); }

        .aipa-title { flex: 1; }
        .aipa-title h1 {
            font-family: 'Syne', 'Vazirmatn', sans-serif;
            font-size: 22px;
            font-weight: 800;
            color: var(--white);
            letter-spacing: -.5px;
            line-height: 1;
        }
        .aipa-title h1 span {
            background: linear-gradient(90deg, var(--accent), var(--accent2), var(--accent3));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .aipa-title p {
            font-size: 11px;
            color: var(--text3);
            margin-top: 3px;
            font-family: 'Vazirmatn', sans-serif;
        }

        .aipa-header-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* ── Status Badge ──────────────────────────── */
        .status-badge {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            border: 1px solid;
        }
        .status-badge.online  { background:rgba(0,229,160,.1); border-color:rgba(0,229,160,.3); color:var(--green); }
        .status-badge.offline { background:rgba(255,77,109,.1); border-color:rgba(255,77,109,.3); color:var(--red); }
        .status-badge.loading { background:rgba(0,200,255,.1); border-color:rgba(0,200,255,.3); color:var(--accent); }
        .status-dot { width:6px; height:6px; border-radius:50%; background:currentColor; animation:pulse 2s infinite; }

        /* ── Buttons ───────────────────────────────── */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            font-family: 'Vazirmatn', sans-serif;
            cursor: pointer;
            border: 1px solid transparent;
            transition: all .2s ease;
            white-space: nowrap;
        }
        .btn:disabled { opacity:.4; cursor:not-allowed; }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            color: #000;
            box-shadow: 0 4px 16px rgba(0,200,255,.3);
        }
        .btn-primary:hover:not(:disabled) {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(0,200,255,.5);
        }
        .btn-ghost {
            background: transparent;
            border-color: var(--border);
            color: var(--text2);
        }
        .btn-ghost:hover:not(:disabled) {
            border-color: var(--accent);
            color: var(--accent);
            background: rgba(0,200,255,.06);
        }
        .btn-danger {
            background: rgba(255,77,109,.15);
            border-color: rgba(255,77,109,.4);
            color: var(--red);
        }
        .btn-success {
            background: rgba(0,229,160,.15);
            border-color: rgba(0,229,160,.4);
            color: var(--green);
        }
        .btn-sm { padding: 5px 10px; font-size: 11px; }

        /* ── Layout ────────────────────────────────── */
        .aipa-layout {
            display: grid;
            grid-template-columns: 1fr 380px;
            gap: 0;
            height: calc(100vh - 130px);
            min-height: 600px;
        }

        /* ── Left Panel (Products) ─────────────────── */
        .aipa-panel-left {
            display: flex;
            flex-direction: column;
            overflow: hidden;
            border-right: 1px solid var(--border);
        }

        /* ── Toolbar ───────────────────────────────── */
        .aipa-toolbar {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 20px;
            background: var(--bg1);
            border-bottom: 1px solid var(--border);
            flex-wrap: wrap;
        }
        .search-box {
            flex: 1;
            min-width: 160px;
            position: relative;
        }
        .search-box input {
            width: 100%;
            background: var(--bg2);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 8px 12px 8px 36px;
            color: var(--text);
            font-size: 12px;
            font-family: 'Vazirmatn', sans-serif;
            outline: none;
            transition: border-color .2s;
        }
        .search-box input:focus { border-color: var(--accent); }
        .search-box input::placeholder { color: var(--text3); }
        .search-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text3);
            font-size: 14px;
            pointer-events: none;
        }

        /* ── Category Tabs ─────────────────────────── */
        .aipa-categories {
            display: flex;
            gap: 6px;
            padding: 10px 20px;
            background: var(--bg1);
            border-bottom: 1px solid var(--border);
            overflow-x: auto;
            scrollbar-width: thin;
            scrollbar-color: var(--border) transparent;
        }
        .aipa-categories::-webkit-scrollbar { height: 3px; }
        .aipa-categories::-webkit-scrollbar-track { background: transparent; }
        .aipa-categories::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
        .cat-tab {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            font-family: 'Vazirmatn', sans-serif;
            cursor: pointer;
            border: 1px solid var(--border);
            background: var(--bg2);
            color: var(--text2);
            white-space: nowrap;
            transition: all .2s;
        }
        .cat-tab:hover { border-color: var(--accent); color: var(--accent); }
        .cat-tab.active {
            background: linear-gradient(135deg, rgba(0,200,255,.2), rgba(123,97,255,.2));
            border-color: var(--accent);
            color: var(--white);
        }
        .cat-count {
            background: rgba(255,255,255,.1);
            border-radius: 10px;
            padding: 1px 5px;
            font-size: 10px;
        }

        /* ── Products Grid ─────────────────────────── */
        .aipa-products {
            flex: 1;
            overflow-y: auto;
            padding: 16px 20px;
            scrollbar-width: thin;
            scrollbar-color: var(--border) transparent;
        }
        .aipa-products::-webkit-scrollbar { width: 4px; }
        .aipa-products::-webkit-scrollbar-track { background: transparent; }
        .aipa-products::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 12px;
        }

        /* ── Product Card ──────────────────────────── */
        .product-card {
            background: var(--bg2);
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
            transition: all .25s ease;
            cursor: pointer;
            position: relative;
            animation: slideIn .3s ease both;
        }
        .product-card:hover {
            border-color: var(--accent);
            transform: translateY(-3px);
            box-shadow: 0 12px 32px rgba(0,200,255,.15);
        }
        .product-card.selected {
            border-color: var(--accent2);
            background: linear-gradient(135deg, var(--bg2), rgba(123,97,255,.1));
            box-shadow: 0 0 20px rgba(123,97,255,.3), inset 0 0 20px rgba(123,97,255,.05);
        }
        .product-card.editing {
            border-color: var(--accent3);
            animation: glowPulse 2s ease-in-out infinite;
        }
        .product-card.updated {
            border-color: var(--green);
            background: linear-gradient(135deg, var(--bg2), rgba(0,229,160,.08));
        }

        .card-select {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 1px solid var(--border);
            background: var(--bg1);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            z-index: 2;
        }
        .product-card.selected .card-select {
            background: var(--accent2);
            border-color: var(--accent2);
            color: white;
        }

        .card-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
            background: var(--bg3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: var(--text3);
        }
        .card-image img { width:100%; height:120px; object-fit:cover; }
        .card-body { padding: 12px; }

        .card-name {
            font-size: 12px;
            font-weight: 700;
            color: var(--white);
            margin-bottom: 6px;
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .card-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        .card-price {
            font-size: 14px;
            font-weight: 800;
            color: var(--accent3);
            font-family: 'Syne', monospace;
        }
        .card-price.has-sale { color: var(--warn); }
        .card-sku {
            font-size: 9px;
            color: var(--text3);
            background: var(--bg3);
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
        }
        .card-cats {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            margin-bottom: 8px;
        }
        .cat-pill {
            font-size: 9px;
            padding: 2px 7px;
            border-radius: 10px;
            background: rgba(0,200,255,.1);
            border: 1px solid rgba(0,200,255,.2);
            color: var(--accent);
        }
        .card-actions {
            display: flex;
            gap: 4px;
        }
        .card-action-btn {
            flex: 1;
            padding: 5px;
            border-radius: 6px;
            font-size: 10px;
            font-family: 'Vazirmatn', sans-serif;
            cursor: pointer;
            border: 1px solid var(--border);
            background: var(--bg3);
            color: var(--text2);
            text-align: center;
            transition: all .15s;
        }
        .card-action-btn:hover { border-color: var(--accent); color: var(--accent); background: rgba(0,200,255,.06); }

        /* ── Inline Edit Overlay ───────────────────── */
        .inline-edit {
            display: none;
            position: absolute;
            inset: 0;
            background: rgba(6,11,20,.95);
            border-radius: 12px;
            padding: 12px;
            flex-direction: column;
            gap: 8px;
            z-index: 10;
            animation: slideIn .2s ease;
        }
        .inline-edit.show { display: flex; }
        .inline-edit label {
            font-size: 10px;
            color: var(--text3);
            font-family: 'Vazirmatn', sans-serif;
        }
        .inline-edit input, .inline-edit textarea {
            width: 100%;
            background: var(--bg2);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 6px 8px;
            color: var(--text);
            font-size: 11px;
            font-family: 'Vazirmatn', sans-serif;
            outline: none;
        }
        .inline-edit input:focus, .inline-edit textarea:focus { border-color: var(--accent); }
        .inline-edit textarea { resize: vertical; min-height: 50px; }
        .inline-edit-actions { display: flex; gap: 6px; margin-top: auto; }

        /* ── Pagination ────────────────────────────── */
        .aipa-pagination {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 20px;
            border-top: 1px solid var(--border);
            background: var(--bg1);
        }
        .page-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            border: 1px solid var(--border);
            background: var(--bg2);
            color: var(--text2);
            cursor: pointer;
            font-size: 12px;
            font-family: 'Vazirmatn', sans-serif;
            transition: all .2s;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .page-btn:hover, .page-btn.active { border-color: var(--accent); color: var(--accent); background: rgba(0,200,255,.08); }
        .page-info { font-size: 11px; color: var(--text3); font-family: 'Vazirmatn', sans-serif; }

        /* ── Right Panel (Chat) ────────────────────── */
        .aipa-panel-right {
            display: flex;
            flex-direction: column;
            background: var(--bg1);
            overflow: hidden;
        }
        .chat-header {
            padding: 14px 16px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--bg0);
        }
        .chat-header-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        .chat-header-info h3 {
            font-size: 13px;
            font-weight: 700;
            color: var(--white);
            font-family: 'Vazirmatn', sans-serif;
        }
        .chat-header-info p { font-size: 10px; color: var(--text3); font-family: 'Vazirmatn', sans-serif; }

        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            scrollbar-width: thin;
            scrollbar-color: var(--border) transparent;
        }
        .chat-messages::-webkit-scrollbar { width: 3px; }
        .chat-messages::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

        .chat-msg {
            display: flex;
            gap: 8px;
            animation: slideIn .2s ease;
        }
        .chat-msg.user { flex-direction: row-reverse; }
        .chat-avatar {
            width: 28px;
            height: 28px;
            border-radius: 8px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        .chat-msg.user .chat-avatar { background: linear-gradient(135deg, var(--accent2), var(--accent)); }
        .chat-msg.ai   .chat-avatar { background: linear-gradient(135deg, #1a1a2e, var(--bg3)); border: 1px solid var(--border); }
        .chat-bubble {
            max-width: 85%;
            padding: 10px 12px;
            border-radius: 12px;
            font-size: 12px;
            line-height: 1.7;
            font-family: 'Vazirmatn', sans-serif;
        }
        .chat-msg.user .chat-bubble {
            background: linear-gradient(135deg, rgba(123,97,255,.25), rgba(0,200,255,.15));
            border: 1px solid rgba(123,97,255,.3);
            color: var(--white);
            border-radius: 12px 2px 12px 12px;
        }
        .chat-msg.ai .chat-bubble {
            background: var(--bg2);
            border: 1px solid var(--border);
            color: var(--text);
            border-radius: 2px 12px 12px 12px;
        }
        .chat-msg.ai.error .chat-bubble {
            background: rgba(255,77,109,.1);
            border-color: rgba(255,77,109,.3);
            color: var(--red);
        }

        /* ── Action Chips in chat ──────────────────── */
        .action-chips {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 8px;
        }
        .action-chip {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-family: 'Vazirmatn', sans-serif;
            border: 1px solid;
            cursor: pointer;
            transition: all .2s;
        }
        .action-chip.pending { background:rgba(0,200,255,.1); border-color:rgba(0,200,255,.3); color:var(--accent); }
        .action-chip.done    { background:rgba(0,229,160,.1); border-color:rgba(0,229,160,.3); color:var(--green); cursor:default; }
        .action-chip.error   { background:rgba(255,77,109,.1); border-color:rgba(255,77,109,.3); color:var(--red); cursor:default; }

        /* ── Typing Indicator ──────────────────────── */
        .typing-indicator {
            display: flex;
            gap: 4px;
            align-items: center;
            padding: 4px 0;
        }
        .typing-indicator span {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--accent);
            animation: pulse .8s ease-in-out infinite;
        }
        .typing-indicator span:nth-child(2) { animation-delay: .15s; }
        .typing-indicator span:nth-child(3) { animation-delay: .3s; }

        /* ── Chat Input ────────────────────────────── */
        .chat-input-area {
            padding: 12px 14px;
            border-top: 1px solid var(--border);
            background: var(--bg0);
        }
        .quick-prompts {
            display: flex;
            gap: 6px;
            margin-bottom: 10px;
            overflow-x: auto;
            scrollbar-width: none;
        }
        .quick-prompts::-webkit-scrollbar { display: none; }
        .quick-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 16px;
            font-size: 10px;
            font-family: 'Vazirmatn', sans-serif;
            cursor: pointer;
            border: 1px solid var(--border);
            background: var(--bg2);
            color: var(--text2);
            white-space: nowrap;
            transition: all .2s;
        }
        .quick-btn:hover { border-color: var(--accent); color: var(--accent); background: rgba(0,200,255,.06); }

        .chat-input-row {
            display: flex;
            gap: 8px;
            align-items: flex-end;
        }
        .chat-textarea {
            flex: 1;
            background: var(--bg2);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 10px 12px;
            color: var(--text);
            font-size: 12px;
            font-family: 'Vazirmatn', sans-serif;
            outline: none;
            resize: none;
            min-height: 40px;
            max-height: 100px;
            line-height: 1.6;
            transition: border-color .2s;
            direction: rtl;
        }
        .chat-textarea:focus { border-color: var(--accent); }
        .chat-textarea::placeholder { color: var(--text3); }
        .send-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
            transition: all .2s;
            box-shadow: 0 4px 12px rgba(0,200,255,.3);
        }
        .send-btn:hover { transform: scale(1.05); box-shadow: 0 6px 16px rgba(0,200,255,.5); }
        .send-btn:disabled { opacity:.4; cursor:not-allowed; transform: none; }

        /* ── Lang Toggle ───────────────────────────── */
        .lang-toggle {
            display: flex;
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
        }
        .lang-btn {
            padding: 6px 10px;
            font-size: 11px;
            font-family: 'Vazirmatn', sans-serif;
            cursor: pointer;
            border: none;
            background: transparent;
            color: var(--text3);
            transition: all .2s;
        }
        .lang-btn.active { background: var(--accent); color: #000; font-weight: 700; }

        /* ── Stats Bar ─────────────────────────────── */
        .aipa-stats {
            display: flex;
            gap: 0;
            border-bottom: 1px solid var(--border);
            background: var(--bg0);
        }
        .stat-item {
            flex: 1;
            padding: 10px 16px;
            border-right: 1px solid var(--border);
            text-align: center;
        }
        .stat-item:last-child { border-right: none; }
        .stat-num {
            font-size: 20px;
            font-weight: 800;
            font-family: 'Syne', monospace;
            color: var(--accent);
            line-height: 1;
        }
        .stat-label {
            font-size: 9px;
            color: var(--text3);
            font-family: 'Vazirmatn', sans-serif;
            margin-top: 2px;
        }

        /* ── Empty State ───────────────────────────── */
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 200px;
            gap: 12px;
            color: var(--text3);
            font-family: 'Vazirmatn', sans-serif;
            font-size: 12px;
            text-align: center;
        }
        .empty-state .icon { font-size: 48px; opacity: .3; }

        /* ── No API key Warning ────────────────────── */
        .api-warning {
            margin: 16px 20px;
            padding: 14px 16px;
            background: rgba(255,107,53,.1);
            border: 1px solid rgba(255,107,53,.3);
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-family: 'Vazirmatn', sans-serif;
            font-size: 12px;
            color: var(--warn);
        }
        .api-warning a { color: var(--accent); text-decoration: none; }
        .api-warning a:hover { text-decoration: underline; }

        /* ── Loading Skeleton ──────────────────────── */
        .skeleton {
            background: linear-gradient(90deg, var(--bg2) 25%, var(--bg3) 50%, var(--bg2) 75%);
            background-size: 200% auto;
            animation: shimmer 1.4s linear infinite;
            border-radius: 6px;
        }

        /* ── Toast Notifications ───────────────────── */
        #aipa-toasts {
            position: fixed;
            bottom: 24px;
            left: 24px;
            display: flex;
            flex-direction: column-reverse;
            gap: 8px;
            z-index: 9999;
        }
        .toast {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            border-radius: 10px;
            font-size: 12px;
            font-family: 'Vazirmatn', sans-serif;
            box-shadow: var(--shadow);
            animation: slideIn .3s ease;
            max-width: 320px;
        }
        .toast.success { background: rgba(0,229,160,.15); border: 1px solid rgba(0,229,160,.4); color: var(--green); }
        .toast.error   { background: rgba(255,77,109,.15); border: 1px solid rgba(255,77,109,.4); color: var(--red); }
        .toast.info    { background: rgba(0,200,255,.15);  border: 1px solid rgba(0,200,255,.4);  color: var(--accent); }

        /* ── Scrollbar global ──────────────────────── */
        #aipa-root ::-webkit-scrollbar { width: 4px; height: 4px; }
        #aipa-root ::-webkit-scrollbar-track { background: transparent; }
        #aipa-root ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

        /* ── Responsive ────────────────────────────── */
        @media (max-width: 1100px) {
            .aipa-layout { grid-template-columns: 1fr; }
            .aipa-panel-right { display: none; }
        }
        </style>

        <!-- ══════════════ MARKUP ══════════════ -->
        <div class="aipa-header">
            <div class="cube-wrapper">
                <div class="cube">
                    <div class="cube-face front">🤖</div>
                    <div class="cube-face back">📦</div>
                    <div class="cube-face left">💡</div>
                    <div class="cube-face right">⚡</div>
                    <div class="cube-face top">🔮</div>
                    <div class="cube-face bottom">✨</div>
                </div>
            </div>
            <div class="aipa-title">
                <h1>AI <span>Product Agent</span></h1>
                <p id="aipa-subtitle">مدیریت هوشمند محصولات | Intelligent Product Manager</p>
            </div>
            <div class="aipa-header-actions">
                <div class="lang-toggle">
                    <button class="lang-btn active" data-lang="fa" onclick="AIPA.setLang('fa')">FA</button>
                    <button class="lang-btn" data-lang="en" onclick="AIPA.setLang('en')">EN</button>
                </div>
                <div id="aipa-status" class="status-badge loading">
                    <span class="status-dot"></span>
                    <span id="status-text">در حال بارگذاری...</span>
                </div>
                <button class="btn btn-ghost btn-sm" onclick="AIPA.loadProducts()">🔄 بازنشانی</button>
                <a href="<?php echo esc_url( $settings_url ); ?>" class="btn btn-ghost btn-sm">⚙️</a>
            </div>
        </div>

        <?php if ( ! $has_key ) : ?>
        <div class="api-warning">
            ⚠️ کلید API هنوز تنظیم نشده است.
            <a href="<?php echo esc_url( $settings_url ); ?>">برای تنظیم کلیک کنید →</a>
        </div>
        <?php endif; ?>

        <!-- Stats Bar -->
        <div class="aipa-stats">
            <div class="stat-item">
                <div class="stat-num" id="stat-total">—</div>
                <div class="stat-label">کل محصولات</div>
            </div>
            <div class="stat-item">
                <div class="stat-num" id="stat-cats">—</div>
                <div class="stat-label">دسته‌بندی‌ها</div>
            </div>
            <div class="stat-item">
                <div class="stat-num" id="stat-selected">۰</div>
                <div class="stat-label">انتخاب شده</div>
            </div>
            <div class="stat-item">
                <div class="stat-num" id="stat-updated">۰</div>
                <div class="stat-label">بروزرسانی شده</div>
            </div>
        </div>

        <!-- Main Layout -->
        <div class="aipa-layout">

            <!-- LEFT: Products Panel -->
            <div class="aipa-panel-left">
                <div class="aipa-toolbar">
                    <div class="search-box">
                        <span class="search-icon">🔍</span>
                        <input type="text" id="aipa-search" placeholder="جستجوی محصول..." oninput="AIPA.onSearch(this.value)">
                    </div>
                    <button class="btn btn-ghost btn-sm" onclick="AIPA.selectAll()" title="انتخاب همه">☑️ همه</button>
                    <button class="btn btn-ghost btn-sm" onclick="AIPA.clearSelection()" title="لغو انتخاب">✖ لغو</button>
                    <button class="btn btn-primary btn-sm" onclick="AIPA.askAboutSelected()" id="btn-ask-selected" disabled>
                        💬 پرسش از AI
                    </button>
                </div>

                <!-- Category Tabs -->
                <div class="aipa-categories" id="aipa-categories">
                    <button class="cat-tab active" data-cat="all" onclick="AIPA.filterCat('all')">
                        🗂 همه <span class="cat-count" id="cat-count-all">—</span>
                    </button>
                    <!-- Dynamic cats injected here -->
                </div>

                <!-- Products Grid -->
                <div class="aipa-products" id="aipa-products">
                    <div class="empty-state">
                        <div class="icon">⏳</div>
                        <div>در حال بارگذاری محصولات...</div>
                    </div>
                </div>

                <!-- Pagination -->
                <div class="aipa-pagination" id="aipa-pagination" style="display:none">
                    <button class="page-btn" id="btn-prev" onclick="AIPA.prevPage()">‹</button>
                    <span class="page-info" id="page-info">صفحه ۱ از ۱</span>
                    <button class="page-btn" id="btn-next" onclick="AIPA.nextPage()">›</button>
                </div>
            </div>

            <!-- RIGHT: Chat Panel -->
            <div class="aipa-panel-right">
                <div class="chat-header">
                    <div class="chat-header-icon">🤖</div>
                    <div class="chat-header-info">
                        <h3>دستیار هوشمند</h3>
                        <p id="chat-product-ctx">محصولی انتخاب نشده</p>
                    </div>
                    <button class="btn btn-ghost btn-sm" onclick="AIPA.clearChat()" style="margin-right:auto">🗑</button>
                </div>

                <div class="chat-messages" id="chat-messages">
                    <!-- Welcome message -->
                    <div class="chat-msg ai">
                        <div class="chat-avatar">🤖</div>
                        <div class="chat-bubble">
                            سلام! من دستیار هوشمند مدیریت محصولات هستم. می‌توانم:<br><br>
                            📦 محصولات را طبقه‌بندی کنم<br>
                            💰 قیمت‌ها را تغییر دهم<br>
                            ✏️ توضیحات را ویرایش کنم<br>
                            📊 گزارش تحلیلی ارائه دهم<br><br>
                            چه کمکی می‌توانم بکنم؟
                        </div>
                    </div>
                </div>

                <!-- Quick Prompts -->
                <div class="chat-input-area">
                    <div class="quick-prompts" id="quick-prompts">
                        <button class="quick-btn" onclick="AIPA.quickSend('تمام محصولات را طبقه‌بندی کن')">📂 طبقه‌بندی</button>
                        <button class="quick-btn" onclick="AIPA.quickSend('گزارش قیمت‌ها بده')">💰 گزارش قیمت</button>
                        <button class="quick-btn" onclick="AIPA.quickSend('محصولات کم‌موجودی را نشان بده')">⚠️ کم‌موجودی</button>
                        <button class="quick-btn" onclick="AIPA.quickSend('بهترین محصولات را پیشنهاد بده')">⭐ پیشنهاد</button>
                    </div>
                    <div class="chat-input-row">
                        <textarea
                            class="chat-textarea"
                            id="chat-input"
                            placeholder="پیام خود را بنویسید... (Enter برای ارسال)"
                            rows="1"
                            onkeydown="AIPA.onChatKeydown(event)"
                            oninput="AIPA.autoResize(this)"
                        ></textarea>
                        <button class="send-btn" id="send-btn" onclick="AIPA.sendChat()" title="ارسال">
                            ➤
                        </button>
                    </div>
                </div>
            </div>

        </div><!-- /.aipa-layout -->

        <!-- Toast container -->
        <div id="aipa-toasts"></div>

        <!-- ══════════════ JAVASCRIPT ══════════════ -->
        <script>
        const AIPA = (() => {

            const AJAX   = <?php echo json_encode( $ajax_url ); ?>;
            const NONCE  = <?php echo json_encode( $nonce ); ?>;
            const LANG0  = <?php echo json_encode( $def_lang ); ?>;

            let state = {
                lang:      LANG0,
                products:  [],       // all loaded products
                filtered:  [],       // after category/search filter
                selected:  new Set(),
                updated:   new Set(),
                page:      1,
                totalPages:1,
                total:     0,
                currentCat:'all',
                categories:{},       // {cat_name: [product_ids]}
                chatHistory: [],     // [{role,content}]
                isLoading: false,
                search:    '',
                searchTimer: null,
                aiCategories: null,  // AI-generated groups
            };

            /* ── Helpers ──────────────────────────────────── */
            const $  = id => document.getElementById(id);
            const el = (tag, cls, html) => {
                const e = document.createElement(tag);
                if (cls) e.className = cls;
                if (html !== undefined) e.innerHTML = html;
                return e;
            };

            function toFaNum(n) {
                return String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
            }

            function fmtPrice(p) {
                if (!p && p !== 0) return '—';
                return Number(p).toLocaleString('fa-IR');
            }

            function toast(msg, type = 'info', dur = 3500) {
                const icons = { success:'✅', error:'❌', info:'ℹ️' };
                const t = el('div', `toast ${type}`, `${icons[type]} ${msg}`);
                $('aipa-toasts').appendChild(t);
                setTimeout(() => t.remove(), dur);
            }

            function setStatus(txt, type = 'loading') {
                const sb = $('aipa-status');
                sb.className = `status-badge ${type}`;
                $('status-text').textContent = txt;
            }

            /* ── Language ─────────────────────────────────── */
            function setLang(lang) {
                state.lang = lang;
                document.querySelectorAll('.lang-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.lang === lang);
                });
                const ta = $('chat-input');
                ta.dir = lang === 'fa' ? 'rtl' : 'ltr';
                ta.placeholder = lang === 'fa'
                    ? 'پیام خود را بنویسید... (Enter برای ارسال)'
                    : 'Type your message… (Enter to send)';
            }

            /* ── Load Products ────────────────────────────── */
            async function loadProducts(page = 1, search = '') {
                state.isLoading = true;
                setStatus('در حال بارگذاری...', 'loading');

                $('aipa-products').innerHTML = `
                    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;">
                        ${Array(8).fill('<div class="skeleton" style="height:200px;border-radius:12px;"></div>').join('')}
                    </div>`;

                const fd = new FormData();
                fd.append('action', 'aipa_get_products');
                fd.append('nonce', NONCE);
                fd.append('page', page);
                fd.append('search', search);

                try {
                    const res  = await fetch(AJAX, { method:'POST', body: fd });
                    const data = await res.json();

                    if (!data.success) throw new Error(data.data?.msg || 'Server error');

                    state.products   = data.data.products;
                    state.page       = data.data.page;
                    state.totalPages = data.data.total_pages;
                    state.total      = data.data.total;

                    buildCategories();
                    applyFilter();
                    renderStats();
                    setStatus('آنلاین | Online', 'online');

                } catch(e) {
                    $('aipa-products').innerHTML = `<div class="empty-state"><div class="icon">⚠️</div><div>${e.message}</div></div>`;
                    setStatus('خطا | Error', 'offline');
                    toast(e.message, 'error');
                } finally {
                    state.isLoading = false;
                }
            }

            function buildCategories() {
                state.categories = { all: state.products.map(p => p.id) };
                state.products.forEach(p => {
                    (p.categories || []).forEach(cat => {
                        if (!state.categories[cat]) state.categories[cat] = [];
                        state.categories[cat].push(p.id);
                    });
                });
                renderCategoryTabs();
            }

            function renderCategoryTabs() {
                const container = $('aipa-categories');
                // keep first (all) button
                const allBtn = container.querySelector('[data-cat="all"]');
                container.innerHTML = '';
                container.appendChild(allBtn);
                $('cat-count-all').textContent = toFaNum(state.products.length);

                Object.entries(state.categories).forEach(([cat, ids]) => {
                    if (cat === 'all') return;
                    const btn = el('button', `cat-tab${state.currentCat === cat ? ' active' : ''}`, `
                        ${cat} <span class="cat-count">${toFaNum(ids.length)}</span>
                    `);
                    btn.dataset.cat = cat;
                    btn.onclick = () => filterCat(cat);
                    container.appendChild(btn);
                });
            }

            function filterCat(cat) {
                state.currentCat = cat;
                document.querySelectorAll('.cat-tab').forEach(b => {
                    b.classList.toggle('active', b.dataset.cat === cat);
                });
                applyFilter();
            }

            function applyFilter() {
                const catIds = state.categories[state.currentCat] || state.products.map(p => p.id);
                const q = state.search.toLowerCase();
                state.filtered = state.products.filter(p =>
                    catIds.includes(p.id) &&
                    (!q || p.name.toLowerCase().includes(q) || (p.sku||'').toLowerCase().includes(q))
                );
                renderProducts();
                renderPagination();
            }

            /* ── Render Products ──────────────────────────── */
            function renderProducts() {
                const grid = $('aipa-products');
                if (!state.filtered.length) {
                    grid.innerHTML = `<div class="empty-state"><div class="icon">📦</div><div>محصولی یافت نشد</div></div>`;
                    return;
                }

                const ITEMS_PER = 20;
                const start = 0, end = state.filtered.length; // all filtered shown (paginated server-side)

                const container = el('div', 'products-grid');
                state.filtered.forEach((p, i) => {
                    container.appendChild(buildCard(p, i));
                });
                grid.innerHTML = '';
                grid.appendChild(container);
            }

            function buildCard(p, idx) {
                const isSelected = state.selected.has(p.id);
                const isUpdated  = state.updated.has(p.id);
                const card = el('div', `product-card${isSelected?' selected':''}${isUpdated?' updated':''}` );
                card.dataset.id = p.id;
                card.style.animationDelay = (idx * 0.03) + 's';

                const hasImage = !!p.image;
                const imgHtml = hasImage
                    ? `<img src="${p.image}" alt="${escHtml(p.name)}" loading="lazy">`
                    : `<div style="font-size:40px;opacity:.3;">📦</div>`;

                const catsHtml = (p.categories||[]).map(c =>
                    `<span class="cat-pill">${c}</span>`
                ).join('');

                const priceClass = p.sale_price ? 'card-price has-sale' : 'card-price';
                const displayPrice = p.sale_price || p.regular_price || p.price || 0;

                card.innerHTML = `
                    <div class="card-select" onclick="event.stopPropagation();AIPA.toggleSelect(${p.id})">
                        ${isSelected ? '✓' : ''}
                    </div>
                    <div class="card-image">${imgHtml}</div>
                    <div class="card-body">
                        <div class="card-name" title="${escHtml(p.name)}">${escHtml(p.name)}</div>
                        <div class="card-meta">
                            <span class="${priceClass}">${fmtPrice(displayPrice)}</span>
                            ${p.sku ? `<span class="card-sku">${p.sku}</span>` : ''}
                        </div>
                        ${catsHtml ? `<div class="card-cats">${catsHtml}</div>` : ''}
                        <div class="card-actions">
                            <button class="card-action-btn" onclick="event.stopPropagation();AIPA.openEdit(${p.id})">✏️ ویرایش</button>
                            <button class="card-action-btn" onclick="event.stopPropagation();AIPA.askAbout(${p.id})">💬 AI</button>
                            ${p.edit_url ? `<a class="card-action-btn" href="${p.edit_url}" target="_blank" onclick="event.stopPropagation()">🔗</a>` : ''}
                        </div>
                    </div>
                    <div class="inline-edit" id="edit-${p.id}">
                        <label>نام محصول</label>
                        <input type="text" id="edit-name-${p.id}" value="${escAttr(p.name)}">
                        <label>قیمت اصلی</label>
                        <input type="number" id="edit-price-${p.id}" value="${p.regular_price||p.price||''}">
                        <label>قیمت فروش (اختیاری)</label>
                        <input type="number" id="edit-sale-${p.id}" value="${p.sale_price||''}">
                        <label>توضیح کوتاه</label>
                        <textarea id="edit-desc-${p.id}" rows="2">${escHtml(p.description||'')}</textarea>
                        <div class="inline-edit-actions">
                            <button class="btn btn-success btn-sm" onclick="AIPA.saveEdit(${p.id})">💾 ذخیره</button>
                            <button class="btn btn-ghost btn-sm" onclick="AIPA.closeEdit(${p.id})">✖</button>
                        </div>
                    </div>
                `;

                card.onclick = () => toggleSelect(p.id);
                return card;
            }

            function escHtml(s) {
                return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
            }
            function escAttr(s) { return escHtml(s); }

            /* ── Selection ────────────────────────────────── */
            function toggleSelect(id) {
                if (state.selected.has(id)) state.selected.delete(id);
                else state.selected.add(id);
                updateSelectionUI();
            }

            function updateSelectionUI() {
                const count = state.selected.size;
                $('stat-selected').textContent = toFaNum(count);
                $('btn-ask-selected').disabled = count === 0;
                $('chat-product-ctx').textContent = count
                    ? `${toFaNum(count)} محصول انتخاب شده`
                    : 'محصولی انتخاب نشده';

                document.querySelectorAll('.product-card').forEach(card => {
                    const id = parseInt(card.dataset.id);
                    card.classList.toggle('selected', state.selected.has(id));
                    const chk = card.querySelector('.card-select');
                    if (chk) chk.innerHTML = state.selected.has(id) ? '✓' : '';
                });
            }

            function selectAll() {
                state.filtered.forEach(p => state.selected.add(p.id));
                updateSelectionUI();
            }

            function clearSelection() {
                state.selected.clear();
                updateSelectionUI();
            }

            /* ── Inline Edit ──────────────────────────────── */
            function openEdit(id) {
                const editEl = document.getElementById(`edit-${id}`);
                if (editEl) {
                    document.querySelectorAll('.inline-edit').forEach(e => e.classList.remove('show'));
                    editEl.classList.add('show');
                    editEl.closest('.product-card').classList.add('editing');
                }
            }

            function closeEdit(id) {
                const editEl = document.getElementById(`edit-${id}`);
                if (editEl) {
                    editEl.classList.remove('show');
                    editEl.closest('.product-card').classList.remove('editing');
                }
            }

            async function saveEdit(id) {
                const name  = document.getElementById(`edit-name-${id}`)?.value || '';
                const price = document.getElementById(`edit-price-${id}`)?.value || '';
                const sale  = document.getElementById(`edit-sale-${id}`)?.value  || '';
                const desc  = document.getElementById(`edit-desc-${id}`)?.value  || '';

                const updates = {};
                if (name)  updates.name = name;
                if (price) updates.regular_price = price;
                if (sale)  updates.sale_price = sale;
                if (desc)  updates.description = desc;

                await updateProduct(id, updates);
                closeEdit(id);
            }

            async function updateProduct(id, updates) {
                const fd = new FormData();
                fd.append('action',     'aipa_update_product');
                fd.append('nonce',      NONCE);
                fd.append('product_id', id);
                fd.append('updates',    JSON.stringify(updates));

                try {
                    const res  = await fetch(AJAX, { method:'POST', body: fd });
                    const data = await res.json();
                    if (!data.success) throw new Error(data.data?.msg || 'Update failed');

                    // Update local state
                    const p = state.products.find(x => x.id === id);
                    if (p) Object.assign(p, updates);
                    state.updated.add(id);
                    $('stat-updated').textContent = toFaNum(state.updated.size);

                    // Refresh card
                    const card = document.querySelector(`.product-card[data-id="${id}"]`);
                    if (card) card.classList.add('updated');

                    toast(`محصول #${id} بروزرسانی شد ✅`, 'success');
                    return true;
                } catch(e) {
                    toast(e.message, 'error');
                    return false;
                }
            }

            /* ── AI Chat ──────────────────────────────────── */
            async function sendChat(msg) {
                const input = $('chat-input');
                const text  = (msg || input.value).trim();
                if (!text) return;
                input.value = '';
                input.style.height = 'auto';

                appendMsg('user', text);
                state.chatHistory.push({ role: 'user', content: text });

                const typingId = appendTyping();
                $('send-btn').disabled = true;

                const fd = new FormData();
                fd.append('action',   'aipa_chat');
                fd.append('nonce',    NONCE);
                fd.append('message',  text);
                fd.append('history',  JSON.stringify(state.chatHistory.slice(-10)));
                fd.append('products', JSON.stringify(state.products.slice(0, 80)));

                try {
                    const res  = await fetch(AJAX, { method:'POST', body: fd });
                    const data = await res.json();

                    removeTyping(typingId);

                    if (!data.success) throw new Error(data.data?.msg || 'AI Error');

                    const reply   = data.data.reply;
                    const actions = data.data.actions || [];

                    state.chatHistory.push({ role: 'assistant', content: data.data.raw || reply });

                    appendMsg('ai', reply, actions);
                    await executeActions(actions);

                } catch(e) {
                    removeTyping(typingId);
                    appendMsg('ai', e.message, [], true);
                } finally {
                    $('send-btn').disabled = false;
                    input.focus();
                }
            }

            function quickSend(txt) {
                $('chat-input').value = txt;
                sendChat(txt);
            }

            function appendMsg(role, text, actions = [], isError = false) {
                const msgs  = $('chat-messages');
                const wrap  = el('div', `chat-msg ${role}${isError ? ' error' : ''}`);
                const avatar = el('div', 'chat-avatar', role === 'user' ? '👤' : '🤖');

                const formatted = text
                    .replace(/\n/g, '<br>')
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/`(.*?)`/g, '<code style="background:rgba(0,200,255,.1);padding:1px 4px;border-radius:3px;font-family:monospace">$1</code>');

                const bubble = el('div', 'chat-bubble', formatted);

                if (actions && actions.length > 0) {
                    const chips = el('div', 'action-chips');
                    actions.forEach((act, i) => {
                        const chip = el('span', 'action-chip pending', `⚡ ${actionLabel(act)}`);
                        chip.dataset.index = i;
                        chips.appendChild(chip);
                    });
                    bubble.appendChild(chips);
                }

                wrap.appendChild(avatar);
                wrap.appendChild(bubble);
                msgs.appendChild(wrap);
                msgs.scrollTop = msgs.scrollHeight;
                return wrap;
            }

            function actionLabel(act) {
                const labels = {
                    update_price:       `تغییر قیمت #${act.product_id}`,
                    update_sale_price:  `قیمت فروش #${act.product_id}`,
                    update_name:        `تغییر نام #${act.product_id}`,
                    update_description: `ویرایش توضیح #${act.product_id}`,
                    bulk_price_percent: `تغییر قیمت گروهی (${act.percent}%)`,
                    categorize:         `طبقه‌بندی (${(act.groups||[]).length} گروه)`,
                };
                return labels[act.type] || act.type;
            }

            function appendTyping() {
                const id   = 'typing-' + Date.now();
                const msgs = $('chat-messages');
                const wrap = el('div', 'chat-msg ai');
                wrap.id    = id;
                wrap.innerHTML = `
                    <div class="chat-avatar">🤖</div>
                    <div class="chat-bubble">
                        <div class="typing-indicator">
                            <span></span><span></span><span></span>
                        </div>
                    </div>`;
                msgs.appendChild(wrap);
                msgs.scrollTop = msgs.scrollHeight;
                return id;
            }

            function removeTyping(id) {
                const el = document.getElementById(id);
                if (el) el.remove();
            }

            async function executeActions(actions) {
                const allChips = document.querySelectorAll('.action-chip.pending');

                for (let i = 0; i < actions.length; i++) {
                    const act  = actions[i];
                    const chip = allChips[i];

                    try {
                        await runAction(act);
                        if (chip) { chip.className = 'action-chip done'; chip.textContent = '✅ ' + actionLabel(act); }
                    } catch(e) {
                        if (chip) { chip.className = 'action-chip error'; chip.textContent = '❌ ' + e.message; }
                    }
                }
            }

            async function runAction(act) {
                switch(act.type) {
                    case 'update_price':
                        return updateProduct(act.product_id, { regular_price: act.regular_price });
                    case 'update_sale_price':
                        return updateProduct(act.product_id, { sale_price: act.sale_price });
                    case 'update_name':
                        return updateProduct(act.product_id, { name: act.name });
                    case 'update_description':
                        return updateProduct(act.product_id, { description: act.description });
                    case 'bulk_price_percent':
                        return runBulkPriceChange(act);
                    case 'categorize':
                        return applyCategorization(act.groups || []);
                    default:
                        throw new Error(`Unknown action: ${act.type}`);
                }
            }

            async function runBulkPriceChange(act) {
                const pct  = parseFloat(act.percent) || 0;
                const dir  = act.direction === 'decrease' ? -1 : 1;
                const cat  = act.category;
                const mult = 1 + (dir * pct / 100);

                const toUpdate = state.products.filter(p =>
                    !cat || p.categories.includes(cat)
                );

                const updates = toUpdate.map(p => ({
                    product_id:    p.id,
                    regular_price: (parseFloat(p.regular_price || p.price || 0) * mult).toFixed(0),
                }));

                const fd = new FormData();
                fd.append('action',  'aipa_bulk_update');
                fd.append('nonce',   NONCE);
                fd.append('updates', JSON.stringify(updates));

                const res  = await fetch(AJAX, { method:'POST', body: fd });
                const data = await res.json();
                if (!data.success) throw new Error('Bulk update failed');

                updates.forEach(u => state.updated.add(u.product_id));
                $('stat-updated').textContent = toFaNum(state.updated.size);
                toast(`${toFaNum(updates.length)} محصول بروزرسانی شد`, 'success');
                await loadProducts(state.page, state.search);
            }

            function applyCategorization(groups) {
                state.aiCategories = groups;
                // Add AI category tabs
                const container = $('aipa-categories');
                groups.forEach(g => {
                    if (container.querySelector(`[data-cat="${g.label}"]`)) return;
                    const btn = el('button', 'cat-tab', `
                        ✨ ${g.label} <span class="cat-count">${toFaNum(g.product_ids.length)}</span>
                    `);
                    btn.dataset.cat = g.label;
                    btn.onclick     = () => filterByCatGroup(g);
                    container.appendChild(btn);
                });
                toast('طبقه‌بندی AI اعمال شد', 'success');
            }

            function filterByCatGroup(group) {
                document.querySelectorAll('.cat-tab').forEach(b => b.classList.remove('active'));
                event.target.closest('.cat-tab').classList.add('active');
                state.filtered = state.products.filter(p => group.product_ids.includes(p.id));
                renderProducts();
            }

            /* ── Ask About Products ───────────────────────── */
            function askAbout(id) {
                const p = state.products.find(x => x.id === id);
                if (!p) return;
                const msg = state.lang === 'fa'
                    ? `درباره محصول "${p.name}" (ID: ${id}) بگو. قیمت: ${fmtPrice(p.regular_price)} - توضیح: ${p.description || 'ندارد'}`
                    : `Tell me about product "${p.name}" (ID: ${id}). Price: ${p.regular_price} - Description: ${p.description || 'none'}`;
                sendChat(msg);
            }

            function askAboutSelected() {
                const ids  = [...state.selected];
                const ps   = state.products.filter(p => ids.includes(p.id));
                const list = ps.map(p => `"${p.name}" (قیمت: ${fmtPrice(p.regular_price)})`).join('، ');
                const msg  = state.lang === 'fa'
                    ? `این ${toFaNum(ids.length)} محصول را تحلیل کن: ${list}`
                    : `Analyze these ${ids.length} products: ${list}`;
                sendChat(msg);
            }

            function clearChat() {
                $('chat-messages').innerHTML = '';
                state.chatHistory = [];
                appendMsg('ai', 'چت پاک شد. چه کمکی می‌توانم بکنم؟ 😊');
            }

            /* ── Stats ────────────────────────────────────── */
            function renderStats() {
                $('stat-total').textContent = toFaNum(state.total);
                $('stat-cats').textContent  = toFaNum(Object.keys(state.categories).length - 1);
            }

            /* ── Pagination ───────────────────────────────── */
            function renderPagination() {
                const pg = $('aipa-pagination');
                if (state.totalPages <= 1) { pg.style.display = 'none'; return; }
                pg.style.display = 'flex';
                $('page-info').textContent = `صفحه ${toFaNum(state.page)} از ${toFaNum(state.totalPages)}`;
                $('btn-prev').disabled = state.page <= 1;
                $('btn-next').disabled = state.page >= state.totalPages;
            }

            function prevPage() { if (state.page > 1) loadProducts(state.page - 1, state.search); }
            function nextPage() { if (state.page < state.totalPages) loadProducts(state.page + 1, state.search); }

            /* ── Search ───────────────────────────────────── */
            function onSearch(val) {
                state.search = val;
                clearTimeout(state.searchTimer);
                state.searchTimer = setTimeout(() => applyFilter(), 350);
            }

            /* ── Keyboard ─────────────────────────────────── */
            function onChatKeydown(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendChat();
                }
            }

            function autoResize(el) {
                el.style.height = 'auto';
                el.style.height = Math.min(el.scrollHeight, 100) + 'px';
            }

            /* ── Init ─────────────────────────────────────── */
            function init() {
                setLang(LANG0);
                loadProducts();
            }

            document.addEventListener('DOMContentLoaded', init);
            // Also init immediately if DOM ready
            if (document.readyState !== 'loading') init();

            return {
                loadProducts, setLang, filterCat, toggleSelect, selectAll, clearSelection,
                openEdit, closeEdit, saveEdit, sendChat, quickSend, clearChat,
                askAbout, askAboutSelected, prevPage, nextPage, onSearch,
                onChatKeydown, autoResize,
            };
        })();
        </script>
        </div><!-- #aipa-root -->
        <?php
    }
}

/* ── Bootstrap ──────────────────────────────────────────────── */
add_action( 'plugins_loaded', function () {
    AI_Product_Agent::get_instance();
} );

/* ── Activation Hook ────────────────────────────────────────── */
register_activation_hook( AIPA_PLUGIN_FILE, function () {
    if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
        deactivate_plugins( plugin_basename( AIPA_PLUGIN_FILE ) );
        wp_die(
            'این پلاگین نیاز به WooCommerce دارد. | This plugin requires WooCommerce.',
            'Plugin Activation Error',
            [ 'back_link' => true ]
        );
    }
} );
